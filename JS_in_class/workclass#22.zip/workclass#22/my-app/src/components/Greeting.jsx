import React from "react";

export const Greeting = () => <h1>Hello people!!!</h1>;
