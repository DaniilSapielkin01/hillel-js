export const GET_MOVIES_PENDING = "GET_MOVIES_PENDING ";
export const GET_MOVIES_RESOLVED = "GET_MOVIES_RESOLVED ";
export const GET_MOVIES_REJECTED = " GET_MOVIES_REJECTED ";
export const URL_MOVIE = "http://subdomain.entony.fs.a-level.com.ua/api/movie";
