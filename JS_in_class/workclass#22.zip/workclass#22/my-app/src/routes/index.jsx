import React from "react";
import { Route } from "react-router-dom";

import { MyMoviesContainer } from "../conteiners/MyMovies";
import { Greeting } from "../components/Greeting";

export const Main = () => {
  return (
    <div>
      <Route path="/" component={Greeting} />
      <Route path="/movies" component={MyMoviesContainer} />
    </div>
  );
};
